module Example
export domath
domath(x) = x + 2
end

module UnregisteredTests
import Unregistered
import Test

Unregistered.greet()

end

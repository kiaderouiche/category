module BuildProjectFixedDeps

greet() = print("Hello World!")

end # module

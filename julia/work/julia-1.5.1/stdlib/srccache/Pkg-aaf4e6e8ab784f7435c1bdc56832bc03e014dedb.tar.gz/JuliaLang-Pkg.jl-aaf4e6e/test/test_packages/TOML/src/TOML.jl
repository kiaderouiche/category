module TOML

greet() = print("Hello World!")

end # module

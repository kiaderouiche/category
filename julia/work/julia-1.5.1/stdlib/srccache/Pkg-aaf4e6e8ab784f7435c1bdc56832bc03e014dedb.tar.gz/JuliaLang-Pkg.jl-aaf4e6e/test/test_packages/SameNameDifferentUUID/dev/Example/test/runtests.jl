using Test, Example
@test domath(2) == 4

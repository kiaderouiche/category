module C

greet() = print("Hello World!")

end # module

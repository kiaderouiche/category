module Runtests
using Test

@test true

end

module Unpruned

greet() = print("Hello World!")

end # module

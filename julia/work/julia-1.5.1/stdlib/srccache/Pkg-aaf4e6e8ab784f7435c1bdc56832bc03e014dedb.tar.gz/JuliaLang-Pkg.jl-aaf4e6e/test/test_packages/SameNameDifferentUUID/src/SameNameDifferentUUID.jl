module SameNameDifferentUUID
greet() = print("Hello World!")
end # module

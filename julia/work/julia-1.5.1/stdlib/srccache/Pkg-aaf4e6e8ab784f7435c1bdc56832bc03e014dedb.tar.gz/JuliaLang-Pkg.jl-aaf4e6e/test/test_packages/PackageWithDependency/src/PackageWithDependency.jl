module PackageWithDependency

greet() = print("Hello World!")

end # module

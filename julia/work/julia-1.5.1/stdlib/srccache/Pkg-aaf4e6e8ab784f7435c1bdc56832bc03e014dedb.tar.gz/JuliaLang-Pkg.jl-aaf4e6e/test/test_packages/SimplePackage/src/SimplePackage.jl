module SimplePackage

greet() = print("Hello World!")

end # module

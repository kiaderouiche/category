module TestFailure
# This is for testing failure cases of a packages tests based on the process exiting abnormally
# See ../test/runtests.jl for details
end # module

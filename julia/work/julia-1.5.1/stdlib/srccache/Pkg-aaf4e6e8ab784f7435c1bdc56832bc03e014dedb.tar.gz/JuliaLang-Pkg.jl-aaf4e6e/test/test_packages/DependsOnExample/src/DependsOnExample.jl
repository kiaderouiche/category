module DependsOnExample

greet() = print("Hello World!")

end # module

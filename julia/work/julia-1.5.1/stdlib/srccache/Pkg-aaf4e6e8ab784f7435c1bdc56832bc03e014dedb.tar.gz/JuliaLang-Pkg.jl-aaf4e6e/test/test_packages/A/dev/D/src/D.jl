module D

greet() = print("Hello World!")

end # module

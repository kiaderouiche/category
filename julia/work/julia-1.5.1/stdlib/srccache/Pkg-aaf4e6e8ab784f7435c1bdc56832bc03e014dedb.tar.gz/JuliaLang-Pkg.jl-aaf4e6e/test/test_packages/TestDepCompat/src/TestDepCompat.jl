module TestDepCompat

greet() = print("Hello World!")

end # module

module TestDepTrackingPath

greet() = print("Hello World!")

end # module

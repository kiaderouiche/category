module FooTests

import Foo
import Example

Foo.greet()
Example.hello("human")

end

module RunTests
import Example

Example.domath(0)

end

module EmptyPackage

greet() = print("Hello World!")

end # module

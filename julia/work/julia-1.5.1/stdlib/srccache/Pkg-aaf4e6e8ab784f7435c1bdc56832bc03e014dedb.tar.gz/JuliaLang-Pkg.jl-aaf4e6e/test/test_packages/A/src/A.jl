module A

greet() = print("Hello World!")

end # module

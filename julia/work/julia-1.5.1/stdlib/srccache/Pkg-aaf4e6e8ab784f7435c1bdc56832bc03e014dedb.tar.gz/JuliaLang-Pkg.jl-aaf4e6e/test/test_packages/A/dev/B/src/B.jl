module B

greet() = print("Hello World!")

end # module

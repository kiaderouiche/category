module BasicCompat

greet() = print("Hello World!")

end # module

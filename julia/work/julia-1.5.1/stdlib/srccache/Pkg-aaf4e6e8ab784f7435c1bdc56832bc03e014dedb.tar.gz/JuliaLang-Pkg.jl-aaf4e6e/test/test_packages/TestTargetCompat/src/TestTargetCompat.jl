module TestTargetCompat

greet() = print("Hello World!")

end # module

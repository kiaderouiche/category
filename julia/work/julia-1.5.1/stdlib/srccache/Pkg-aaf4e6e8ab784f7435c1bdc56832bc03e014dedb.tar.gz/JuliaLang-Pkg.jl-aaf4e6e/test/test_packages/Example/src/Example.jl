module Example

greet() = print("Hello World!")

end # module

module ActiveProjectInTestSubgraph

greet() = print("Hello World!")

end # module

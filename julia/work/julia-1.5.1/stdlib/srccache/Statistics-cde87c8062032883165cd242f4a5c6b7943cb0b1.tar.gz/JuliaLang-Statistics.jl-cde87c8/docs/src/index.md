# Statistics

The Statistics standard library module contains basic statistics functionality.

```@docs
std
stdm
var
varm
cor
cov
mean!
mean
median!
median
middle
quantile!
quantile
```
